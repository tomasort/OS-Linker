# NYU OS Lab 1

Net-ID: tor213


Name: Tomas Ortega Rojas

# Important Information

In this lab we use g++-9.2 so we must load the module first. Even though the makefile already loads the module, It is recommended to do so.

use ```module load gcc-9.2```

to create the executable linker, use ```make```

